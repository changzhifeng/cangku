/**
 * 刮刮乐实现思路：
 * 1、创建一个canvas画布标签
 * 2、在画布标签身上设置一个背景(设置奖品)
 * 3、在画布上绘制遮罩层(遮盖奖品)
 * 4、把画布放置到页面当中(html文档当中)
 * 5、监听鼠标事件(mousedown、mousemove、mouseup)
 *  当鼠标按下并且移动的时候，
 *  我们要根据鼠标移动的轨迹一点一点的清除遮罩层，
 *  并且当用户挂到大于50%的时候，自动去掉整个遮罩层。
 * */

// 1、创建一个canvas画布标签
function createCanvas(width = 500, height = 500) {
  const canvasNode = document.createElement("canvas");
  canvasNode.width = 500;
  canvasNode.height = 500;
  return canvasNode;
}

// 2、在画布标签身上设置一个背景(设置奖品)
function setPrize(canvas) {
  // 奖品
  const prizes = [
    "./imgs/1.png",
    "./imgs/2.png",
    "./imgs/3.png",
    "./imgs/4.png",
    "./imgs/5.png",
    "./imgs/6.jpg",
    "./imgs/7.jpg",
  ];

  // 随机取其中一个奖品: 生产随机数 0 ~ 6
  const random = Math.floor(Math.random() * prizes.length);
  const prize = prizes[random];

  // 把奖品设为画布的背景
  $(canvas).css({
    backgroundImage: `url(${prize})`,
    backgroundSize: "100% 100%"
  });
}

// 3、在画布上绘制遮罩层(遮盖奖品)
function mask(canvas) {
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "grey";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

// 4、把画布放置到页面当中(html文档当中)
function appendToPage(canvas) {
  const bodyNode = document.querySelector("body");
  bodyNode.appendChild(canvas);
}

// 5、监听鼠标事件(mousedown、mousemove、mouseup), 实现用户刮的效果
function clean() {
  $(canvas).on("mousedown", () => {

    $(canvas).on("mousemove", (event) => {

      // 1. 拿到鼠标相对于画布的坐标点
      const x = event.pageX - canvas.offsetLeft;
      const y = event.pageY - canvas.offsetTop;

      // 2. 设置画布重叠部分的渲染模式(图像合成模式)
      const ctx = canvas.getContext("2d");
      // 这一步很关键，如果不设置，那么无法实现刮刮效果
      // 重叠之外的图像才展示，反过来的意思就是：重叠部分不展示(透明)
      ctx.globalCompositeOperation = "destination-out";

      // 3. 根据鼠标坐标点的轨迹绘制圆
      ctx.beginPath();
      ctx.arc(x, y, 20, 0, Math.PI * 2);
      ctx.fillStyle = "skyblue";
      ctx.fill();

      // 判断用户是否刮了50%的面积，是的话去掉遮罩层
      fullShow(canvas);
    });
  });

  $(canvas).on("mouseup", () => {
    $(canvas).off("mousemove");
  });
}

// 判断用户是否刮了50%的面积，是的话去掉遮罩层
function fullShow(canvas) {
  const ctx = canvas.getContext("2d");
  const canvasData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  const dataLen = canvasData.length;
  let alphaNumber = 0;

  // canvasData里面每4个数据代表一个像素(rgba)，其中第4个数据代表透明度
  for(let i = 0; i < dataLen; i += 4) {
    // i的值依次为：0 4 8 12 16, 
    // 这是每个数据中第一个数据的位置，
    // 透明数据的位置我们要i+3
    if (canvasData[i + 3] === 0) {
      alphaNumber++;
    }
  }

  // 如果有一半透明度为0，那么去掉遮罩层
  if (alphaNumber / (dataLen / 4) >= 0.5) {
    $(canvas).off("mousemove");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
}

const canvas = createCanvas();
setPrize(canvas);
mask(canvas);
appendToPage(canvas);
clean(canvas);
/*
	短期愿景1:将img图片生成到页面
*/
/* 声明全局 参数  body 宽度 - 图片自身 -右下角的成绩牌 - margin*/
var maxWidth = document.body.clientWidth - 100 - 200 - 50;
var maxHeight = document.body.clientWidth;
var letters = [];
var lose_score = document.getElementById('lose_score');
var score = document.getElementById('score');
var final_score = document.getElementById('final_score');
var gameover = document.getElementById('go');
var timer;
// 如果屏幕尺寸发生改变
window.onresize = function () {
	maxWidth = document.body.clientWidth - 100 - 200 - 50;
	maxHeight = document.body.clientWidth;
}
// 绑定键盘事件
window.onkeypress = function (e) {
	// 1. 遍历letters数组
	// 2. 如果其中一个等于 e.key.toUpperCase()
	// 3. 删除这个元素
	for (var i = 0; i < letters.length; i++) {
		var letter = letters[i];
		if (e.key.toUpperCase() == letter.content) {
			// 如果不是仅仅删除一个元素，那么随着i的++ 与元素的减少后的索引重排，
			// 那么就会跳过一个
			letters.splice(i--,1);
			// 删除页面元素
			letter.ele.remove();
			// 加分
			score.innerText -= -1;
			return;
		}
	}
}
/*
 创建页面元素: 
 	1. 通过document对象创建一个img元素
 	2. 给该元素设置样式 absolute/left/top/src 
 	3. 插入到父级中  document.body.appendChild(img)
 	4. 返回创建的元素
*/
function createImageElement (content,leftValue) {
	var img = document.createElement('img');
	img.src = './img/letter/' + content + '.png';
	img.style.position = 'absolute';
	img.style.left = leftValue + 'px';  //  暂留着
	img.style.top = '-100px';
	// 加一个过渡效果
	img.style.transition = 'top 1s';
	document.body.appendChild(img);
	return img;
}
function getRandomByLimit(begin,end) {
				//	0- 99.9%    求25的随机百分比   24.xx
	return begin +   Math.round(Math.random() * ( end - begin ));
} 
/*
	创建字母对象:
		1. 声明一个随机函数, 返回一个随机数字，参数(begin,end)
		2. 通过随机数根据askII码表中65~91 代表A-Z，获取A-Z中的字符
			2-1. 用数字获取字符A-Z，String.fromCodePoint(65)(数字)
		3. 传递到 createImageElement函数中
		关于位置(left)
		4.起始0, 结束maxWidth 的一个随机范围
*/
function Letter () {
	var strRandomNumber = getRandomByLimit(65,90);
	this.content = String.fromCodePoint(strRandomNumber);
	var leftRandomNumber = getRandomByLimit(0,maxWidth);
	// 构造函数， 每new一次就是一个新的个体
	this.ele = createImageElement(this.content,leftRandomNumber); 	
}
Letter.prototype.move = function () {
	// 1. 移动前判断是否出界
	if (this.ele.offsetTop >= maxHeight) {
		// 删除页面元素
		this.kill();
		// 2: 加一个失分
		lose_score.innerText -= -1;
		return; // 后续代码不执行
	}
	this.ele.style.top = (this.ele.offsetTop + 100) + 'px';
}
/* 干掉自己 */
Letter.prototype.kill = function () {
	// 1: 要从数组中删除元素
	// 1-1 ： 查找元素
	var index = letters.indexOf(this);
	// 删除
	letters.splice(index,1);
	// 删除页面元素img
	this.ele.remove();
}
function gameoverFn () {
		// 清除定时器
		clearInterval(timer); // 取消定时器
		// 成绩
		final_score.innerText = score.innerText;
		// 展示gameover
		gameover.style.display = 'block';
		// 清除事件 on
		window.onresize = null;
		window.onkeypress = null;
}
/*
	游戏中心
*/
function gameStart () {
	// 多个Letter的创建
	timer = setInterval(function () {
			// 判断游戏是否结束
			if (lose_score.innerText >= 10) {
				gameoverFn();
			}
			var letter = new Letter();
			// 大家一起移动
			letters.push(letter);
			// 遍历数组
			letters.forEach(function (letter) {
				letter.move();
			});
	},1000);

}

// 浏览器自动调用
window.onload = gameStart;
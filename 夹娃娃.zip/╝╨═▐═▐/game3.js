var game = document.querySelector('.game');
var button = document.querySelector('.button');
var claw = document.querySelector('.claw');
var girls = document.querySelector('.girls');
var score = document.querySelector('.g_num');
var boxMaxWidth = 470;
var girlWidth = 200;
var clawMaxHeight = 350;
var clawMinHeight = 80;
var allGirls = [];
var i = f => setInterval(f,1000);
var t = f => setTimeout(f,1000);

function Girl (x) {
	this.left = x;
	var div = document.createElement('div');
	this.ele = div;
	girls.appendChild(div);
	this.show();
	this.move();
}
Girl.prototype.show = function () {
	this.ele.style.left = this.left + 'px';
}
Girl.prototype.move = function () {
	this.timer = setInterval(()=>{
		if (this.left > boxMaxWidth) {
			return this.kill();
		}
		this.left++;
		this.show();
	},8);
}
Girl.prototype.kill = function () {
	if (index == -1) return;
	clearInterval(this.timer);
	this.ele.remove();
	var index = allGirls.indexOf(this);
	allGirls.splice(index,1);
	var newGirl = new Girl(allGirls[0].left - girlWidth);
	allGirls.unshift(newGirl);
}
Girl.prototype.canBeCatched = function () {
	console.log(this.left);
	if (this.left >= 110 && this.left <= 170 ) {
		console.log('抓到');
		return true;
	}
	return false;
}
Girl.prototype.catched = function () {

	clearInterval(this.timer);
	this.ele.style.transition = 'transform 1s linear';
	this.ele.style.transform = 'translate(0,-250px)';
	t(()=>{
		score.innerText -= -1;
		this.kill();
	})
}
function Claw () {
	this.ele = claw;
}
Claw.prototype.moveUp = function () {
	this.ele.style.height = clawMinHeight + 'px';
	t(()=>{
		this.ele.classList.add('open');
	})
}
Claw.prototype.moveDown = function () {
	this.ele.style.height = clawMaxHeight + 'px';
	t(()=>{
		this.ele.classList.remove('open');
		this.catch();
		this.moveUp()
	})
}
Claw.prototype.catch = function () {
	for (var i = 0; i < allGirls.length; i ++ ) {
		let g = allGirls[i];
		if (g.canBeCatched()) {
			return g.catched();
		}
	}
}


function Game () {
	this.start = function () {
		var count = 3;
		for (var i = count-1; i >= 0; i--) {
			var girl = new Girl(i*-200);
			allGirls.push(girl);
		}
	}
	var c = new Claw();
	button.onclick = function (e) {
		let btn = e.target;
		if (btn.classList.contains('down'))return;
		btn.classList.add('down');
		c.moveDown();
		setTimeout(function () {
			btn.classList.remove('down');
		},2000)
	}
}

new Game().start();

var game = document.querySelector('.game');
var logo = document.querySelector('.logo');
var button = document.querySelector('.button');
var claw = document.querySelector('.claw');
var girls = document.querySelector('.girls');
var score = document.querySelector('.score');
var g_num = document.querySelector('.g_num');
var boxWidth = 470;
var girlWidth = 200;
// 爪子上的最高点
var clawMinHeight = 80;  // 上
var clawMaxHeight = 350; // 下
var allGirl = [];// 保存所有的妹子
// 抓娃娃范围 left 110~170之间

// 女孩
function Girl (x) {
	this.left = x;
	// 创建DOM元素
	var div = document.createElement('div');
	// 其他属性 绝对定位等。都已经设置
	// 保存该元素
	this.ele = div;
	// 初始的显示
	this.show();
	// 移动
	this.move();
	girls.appendChild(div);
}
Girl.prototype.show = function () {
	this.ele.style.left = this.left + 'px';
}
// 女孩移动 (移动速度建议是8)
Girl.prototype.move = function () {
	var self = this;
	// 定时器每隔8毫秒移动一次(保存定时器)
	this.timer = setInterval(function () {
		// 判断还能跑吗？
		if (self.left > boxWidth) {
			// 干掉自己
			self.kill();
			return;
		}
		// 需要移动
		// self.left = self.left + 1;
		self.left ++;
		// 更新移动
		self.show();
	},8);
}
// 出界干掉自己
Girl.prototype.kill = function () {
	// 一个出界的女孩 (定时器多了会卡)
	clearInterval(this.timer);
	// 删除this.ele
	this.ele.remove();
	// 删除数组的元素(先查找)
	var idx = allGirl.indexOf(this);
	if (idx != -1) allGirl.splice(idx,1);
	// 创建这个妹子
		// 妹子的位置[1,2,3] => [1,2]
	// 找到第一个元素
	var first = allGirl[0];
	var newGirl = new Girl(first.left - girlWidth);
	// 在开头的位置新加一个妹子
	// [1,2] push(3) -> [1,2,3]
	// [1,2] unshift(0) -> [0,1,2]
	allGirl.unshift(newGirl);
}
Girl.prototype.canBeCatched = function () {
	console.log(this.left);
	if (this.left >= 110 && this.left <= 170) {
		console.log('被抓住了');
		return true;
	}
	return false;
}
Girl.prototype.catched = function () {
	clearInterval(this.timer);// 定身术
	// 自己向上飞 ... top 向上飞250px;
	this.ele.style.transition = 'transform 1s linear';
	this.ele.style.transform = 'translate(0,-250px)';
	var self = this;
	// 定时干掉妹子
	setTimeout(function () {
		self.kill();
		g_num.innerText -= -1; //'2'-(-1)=1 
	},1000);
}
// 爪子
function Claw () {
	this.ele = claw;
}

Claw.prototype.moveDown = function () {
	this.ele.style.height = clawMaxHeight + 'px';
	var self = this;
	setTimeout(function () {
		// 夹子收起
		self.ele.classList.remove('open');
		// 抓妹子
		self.catch();
		// 夹了以后 往上提
		self.moveUp();
	},1000);
}
Claw.prototype.moveUp = function () {
	this.ele.style.height = clawMinHeight + 'px';
	var self = this;
	// 夹子飞上去以后
	setTimeout(function (){
		// 夹子放开
		self.ele.classList.add('open');
	},1000);
}
// Claw.prototype.catch = function () {}
// 函数名相同后面的会覆盖前面的
Claw.prototype.catch = function () {
	console.log('catch被调用')
	// 遍历所有的妹子,看看谁能被抓到
	for (var i = 0; i < allGirl.length; i ++) {
		var girl = allGirl[i];
		if (girl.canBeCatched()) {
			// 已经被抓(删除妹子并补货)
			girl.catched();
		}
	}
}
// 控制中心
function Game () {
	this.start = function (count) {
		for (var i = count-1; i >= 0; i --) {
			var girl = new Girl(i * -200)
			allGirl.push(girl);
		}
		// 等会再写
		var c = new Claw();
		// 按钮触发点击事件
		button.onclick = function (e) {
			var btn = e.target;
			// 判断一下当前如果是按下去，就结束
			if (btn.classList.contains('down')) {
				return;
			}
			// 添加按下的样式
			btn.classList.add('down');
			c.moveDown();
			// 2秒后删除down的样式（按钮弹起）
			setTimeout(function () {
				btn.classList.remove('down')
			},2000);


		}
		
	}
}

new Game().start(3);

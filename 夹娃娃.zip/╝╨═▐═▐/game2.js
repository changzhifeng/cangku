var box = document.querySelector('.girls');
var boxMaxWidth = 470;
var girlWidth = 200;
var clawMaxHeight = 350;
var clawMinHeight = 80;

// 创建娃娃的函数
function Girl (x) {
	var div = document.createElement('div');
	box.appendChild(div);
	this.ele = div;
	this.left = x;
	this.show();
	this.Move();
}
Girl.prototype.show = function () {
	this.ele.style.left = this.left + 'px';
}
Girl.prototype.kill = function () {
		// 删除元素
	this.ele.remove()
	// 删除数组
	var index = girls.indexOf(this);
	girls.splice(index,1);
	clearInterval(this.timer);
	// 重生
	var g = new Girl(girls[0].left - girlWidth);
	girls.unshift(g);
}
Girl.prototype.canCatched = function () {
	console.log(this.left);
	if (this.left >= 110 && this.left <= 170) {
		return true;
	}
	return false;
}
Girl.prototype.catched = function () {
	this.ele.style.transition = 'transform 1s linear';
	this.ele.style.zIndex = 1;
	this.ele.style.transform = 'translate(0,-250px)';
	var self = this;
	clearInterval(this.timer);
	setTimeout(function () {
		self.kill();
	},1000);
}
Girl.prototype.Move = function () {
	var self = this;
	this.timer = setInterval(function () {
		if (self.left > boxMaxWidth) {
			self.kill();
			// 干掉女孩
			return;
		}
		self.left ++;
		self.show();
	},8);
}
function Claw () {
	this.ele = document.querySelector(".claw");
}
Claw.prototype.moveUp = function () {
	this.ele.style.height = clawMinHeight + 'px';
	var self = this;
	setTimeout(function () {
		self.ele.classList.add('open');
	},1000)
}
Claw.prototype.moveDown = function () {
	this.ele.style.height = clawMaxHeight + 'px';
	var self = this;
	setTimeout(function () {
		self.ele.classList.remove('open');
		self.moveUp();
		self.catch();
	},1000)
}
Claw.prototype.catch = function () {
	for (var i = 0; i < girls.length; i++) {
		var girl = girls[i];
		if (girl.canCatched()) {
			console.log('抓到')
			return girl.catched();
		} else {
			console.log('没抓到')
		}
	}
}
var girls = [];
function Game (count) {
	this.start = function () {
		for (var i = 0; i < count; i ++ ) {
			var girl = new Girl((i-count) * girlWidth);
			girls.push(girl);
		}
	}
	var btn = document.querySelector('.button');
	var claw = new Claw();
	btn.onclick = function (e) {
		e.target.classList.add('down');
		claw.moveDown();
	}
}

window.onload = new Game(3).start;